<x-layout>
    Order confirmed
</x-layout>
