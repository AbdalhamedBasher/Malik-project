@extends('layouts.m1')
<br><br><br><br><br><br>
@section('content')
<div class="container " >
    <br />
    <div class=" ">
        <h1 style="font-size: 2em;"><b>البحث عن دورة</b></h1>
    </div>
    <br />
    <livewire:course-table/>


</div>
