<footer class="footer-area">
    <div class="container">


    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="copyright_part_text text-center">
                    <div class="row">
                        <div class="col-lg-12">
                        <div class="site-description">
                            <div class="site-contact footer" style="
                            margin: 10rem;
                        ">
                	<a href="http://10.0.151.29/airdef"><span class="address"><i class="fa fa-map-marker"></i>قسم المناهج والتعليم الإلكتروني - إدارة تدريب قوات الدفاع الجوي</span> </a> <a href="http://tre144@rsadf.mail"><span class="mail"><i class="fa fa-envelope-o"></i>tre144@rsadf.mail</span> </a> <span class="phone"><i class="fa fa-phone"></i>1003537</span> 	</div>
	 			</div>
                <br><br><br>
                            <p class="footer-text m-0">
                            جميع الحقوق محفوظة © 2022
                            <br>
قسم المناهج والتعليم الالكتروني - إدارة تدريب قوات الدفاع الجوي
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
