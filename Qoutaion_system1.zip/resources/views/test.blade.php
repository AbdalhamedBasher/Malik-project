@extends('layouts.admin')
@section('content')



<div class="bg-red w-72 shadow-black shadow-2xl">
    <div class="flex justify-between m-4" >
        <div>139 <br>القوة</div>
        <div> icon</div>
    </div>
     <div class="flex justify-between ">
            <div>1</div>
            <div>2</div>
            <div>3</div>
        </div>
</div>
@endsection
