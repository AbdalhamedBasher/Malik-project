@extends('layouts.m1')
<br><br><br><br><br><br>
@section('content')
<div class="container" >
    <br />
    <div class="flex items-center ">
        <h1 style="font-size: 2em;"><b>  البحث عن مقرر</b></h1>
    </div>
    <br />
    <livewire:material-table/>

</div>
