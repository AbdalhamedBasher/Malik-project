<x-layout>
    <livewire:review-wizard />
</x-layout>
