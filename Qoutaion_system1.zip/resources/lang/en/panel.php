<?php

return [
    'site_title' => 'Courses Enrollment',
];
