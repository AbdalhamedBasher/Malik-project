<?php

return [
    'site_title' => 'إدارة تدريب',
];
