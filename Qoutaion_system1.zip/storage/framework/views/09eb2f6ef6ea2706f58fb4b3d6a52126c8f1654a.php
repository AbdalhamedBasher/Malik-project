<!DOCTYPE html>
<html dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>شاشة الدخول لنظام التسعيرات</title>









    <script src="<?php echo e(asset('js/jquery-3.3.1.slim.min.js')); ?>" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" crossorigin="anonymous"></script>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('font-awesome-4.7.0/css/font-awesome.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('font-awesome-4.7.0/css/font-awesome.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/jquery.dataTables.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/buttons.dataTables.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/select.dataTables.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/coreui.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('font-awesome-4.7.0/css/font-awesome.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/bootstrap-datetimepicker.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/dropzone.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" />
       <script src="<?php echo e(asset('js/alpinejs.cdn.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/alpinejs.cdn.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/flasher.min.js')); ?>" defer></script>
      <script src="<?php echo e(asset('js/cdn.min.js')); ?>" defer></script>
    <?php echo $__env->yieldContent('styles'); ?>
    <style>
        @font-face {
            font-family: 'OptimusPrinceps';
        src: url('<?php echo e(asset('/fonts/almarai/Almarai-Regular.ttf')); ?>');
    }
        *{

    font-family: 'OptimusPrinceps';

        }
    </style>
</head>

<body class="header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden login-page">
    <div class="app flex-row align-items-center" style="
    background: #625395d1;
">
        <div class="container">
            <?php echo $__env->yieldContent("content"); ?>
        </div>
    </div>

    <?php echo $__env->yieldContent('scripts'); ?>


</body>

</html>
<?php /**PATH C:\Users\user\Documents\GitHub\Qoutaion_system\resources\views/layouts/app1.blade.php ENDPATH**/ ?>