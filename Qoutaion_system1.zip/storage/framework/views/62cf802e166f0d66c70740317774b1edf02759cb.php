<?php $__env->startSection('content'); ?>

    





<?php $__env->startSection('content'); ?>
    <div class="flex items-center markdown">

    </div>

    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn" id="icons" style="background-color: #433483a3 ; color:aliceblue">
                إضافة تصنيف جديد
            </a>
        </div>
    </div>
    <div class="card mt-1">
        <div class="card-header" style="background-color: #433483a3 ; color:aliceblue">

        </div>

        <div class="card-body">


            <div class="table-responsive">
                <table class=" table table-bordered table-striped table-hover datatable datatable-Course"
                    style="text-align: center">
                    <thead>
                        <tr>
                            <th width="10">
                                #
                            </th>

                            <th style="text-align: center">
                                اسم التصنيف
                            </th>
                            <th style="text-align: center">
                                التصنيف الاساسي
                            </th>
                            <th style="text-align: center">
                               النشاط
                            </th>

                            <th>
                                &nbsp;
                            </th>
                        </tr>
                    </thead>
                    <tbody>


                        <?php
                            $i = 1;
                        ?>
                        <?php $__currentLoopData = $catogery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-entry-id="">
                                <td><?php echo e($i++); ?></td>
                                <td id="name"><?php echo e($item->name); ?></td>

                                <td id="name"><?php echo e(is_null($item->main_catogery)?'':$item->main->name); ?></td>
                                <td id="name"><?php echo e(is_null($item->line)?'1':$item->lines->name); ?></td>

                                <td>

                                    <span class="d-flex space-x-1">
                                        <a class="btn update m-1" style="background-color: #433483a3 ; color:aliceblue"
                                            data-id="<?php echo e($item->id); ?>" data-name="<?php echo e($item->name); ?>"  data-catogery="<?php echo e($item->line); ?>"
                                            data-catogery="<?php echo e($item->main_catogery); ?>">
                                            تعديل </a>

                                        <button type="submit" class="btn btn-danger m-1 delete"
                                            data-id="<?php echo e($item->id); ?>" data-name="<?php echo e($item->name); ?>">مسح</button>

                                    </span>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                    </tbody>
                </table>
            </div>


        </div>
    </div>
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header" style="background-color:#433483a3  ;color:#e6e4eca3 ; font-size:1rem">

                    </div>

                    <div class="card-body">
                        <form action="<?php echo e(url('catogery')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                <label for="name">اﻹسم*</label>
                                <input type="text" id="name" name="name" class="form-control"
                                    value="<?php echo e(old('name', isset($user) ? $user->name : '')); ?>" required>
                                <?php if($errors->has('name')): ?>
                                    <em class="invalid-feedback">
                                        <?php echo e($errors->first('name')); ?>

                                    </em>
                                <?php endif; ?>
                                <p class="helper-block">
                                    <?php echo e(trans('cruds.user.fields.name_helper')); ?>

                                </p>
                            </div>
                            <div class="form-group <?php echo e($errors->has('line_catogery') ? 'has-error' : ''); ?>">
                                <label for="line_catogery">التصنيف</label>


                                <select class="form-control" id="exampleFormControlSelect1 main_catog" name="main_catogery">
                                    <option selected value="">-- إختر --</option>
                                    <?php $__currentLoopData = $catogery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>



                                <?php if($errors->has('main_line')): ?>
                                    <em class="invalid-feedback">
                                        <?php echo e($errors->first('main_line')); ?>

                                    </em>
                                <?php endif; ?>
                                <label for="line">الخدمة</label>
                                <select class="form-control" id="exampleFormControlSelect1 main_catog" name="line">
                                    <option selected value="">-- إختر --</option>
                                    <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($line->id); ?>"><?php echo e($line->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>"
                                style="border-radius: 50%;border:1px">
                                <span style="border-radius: 3rem">
                                </span>
                            </div>

                            <hr>

                            <div>

                                <input class="btn btn-primary" style="" type="submit" value="حفظ">
                            </div>
                        </form>


                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    
    <div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header" style="background-color:#433483a3  ;color:#e6e4eca3 ; font-size:1rem">

                    </div>

                    <div class="card-body">
                        <form action="<?php echo e(url('catogery/update')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>" id="formupdate">
                                <input type="hidden" id="id" name="id" class="form-control"
                                    value="<?php echo e(old('name', isset($user) ? $user->name : '')); ?>" required>

                                <label for="name">اﻹسم*</label>
                                <input type="text" id="name" name="name" class="form-control"
                                    value="<?php echo e(old('name', isset($user) ? $user->name : '')); ?>" required>
                                <?php if($errors->has('name')): ?>
                                    <em class="invalid-feedback">
                                        <?php echo e($errors->first('name')); ?>

                                    </em>
                                <?php endif; ?>
                                <p class="helper-block">
                                    <?php echo e(trans('cruds.user.fields.name_helper')); ?>

                                </p>
                            </div>

                            <div class="form-group <?php echo e($errors->has('main_line') ? 'has-error' : ''); ?>">
                                <label for="main_line">الخدمة الاساسية</label>
                                <select class="form-control" id="exampleFormControlSelect1 catogery" name="main_line">
                                    <option selected value="">-- إختر --</option>
                                    <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($line->id); ?>"><?php echo e($line->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php if($errors->has('main_line')): ?>
                                    <em class="invalid-feedback">
                                        <?php echo e($errors->first('main_line')); ?>

                                    </em>
                                <?php endif; ?>
                            </div>

                            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>"
                                style="border-radius: 50%;border:1px">
                                <span style="border-radius: 3rem">
                                </span>
                            </div>
                            <hr>
                            <div>

                                <input class="btn btn-primary" style="" type="submit" value="حفظ">
                            </div>
                        </form>


                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>

    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header" style="background-color:#433483a3  ;color:#e6e4eca3 ; font-size:1rem">

                    </div>

                    <div class="card-body">

                            <P class="text-bold">
                                هل تريد مسح الخدمة؟
                            </P>
                            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>" id="formupdate">



                                <input type="text" id="name" name="name" class="form-control"
                                    value="<?php echo e(old('name', isset($user) ? $user->name : '')); ?>" disabled>
                                <?php if($errors->has('name')): ?>
                                    <em class="invalid-feedback">
                                        <?php echo e($errors->first('name')); ?>

                                    </em>
                                <?php endif; ?>
                                <p class="helper-block">
                                    <?php echo e(trans('cruds.user.fields.name_helper')); ?>

                                </p>
                            </div>



                            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>"
                                style="border-radius: 50%;border:1px">
                                <span style="border-radius: 3rem">
                                </span>
                            </div>


                            <div class="d-flex">
                                <form action="<?php echo e(url('lines/delete')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" id="id" name="id" class="form-control"
                                    value="<?php echo e(old('name', isset($user) ? $user->name : '')); ?>" required>
                                <input class="btn btn-danger b-a-1" style="" type="submit" value="مسح">
                                </form>
                            </div>

                    </div>

                </div>

            </div>

            <div>

            </div>
        </div>

    </div>

    </div>







<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script>
        $(function() {
            let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('course_delete')): ?>
                let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
                let deleteButton = {
                    text: deleteButtonTrans,
                    url: "#1",
                    className: 'btn-danger',
                    action: function(e, dt, node, config) {
                        var ids = $.map(dt.rows({
                            selected: true
                        }).nodes(), function(entry) {
                            return $(entry).data('entry-id')
                        });

                        if (ids.length === 0) {
                            alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

                            return
                        }

                        if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
                            $.ajax({
                                    headers: {
                                        'x-csrf-token': _token
                                    },
                                    method: 'POST',
                                    url: config.url,
                                    data: {
                                        ids: ids,
                                        _method: 'DELETE'
                                    }
                                })
                                .done(function() {
                                    location.reload()
                                })
                        }
                    }
                }
                dtButtons.push(deleteButton)
            <?php endif; ?>

            $.extend(true, $.fn.dataTable.defaults, {
                order: [
                    [1, 'desc']
                ],
                pageLength: 100,
            });
            $('.datatable-Course:not(.ajaxTable)').DataTable({
                buttons: dtButtons
            })
            $('a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
                $($.fn.dataTable.tables(true)).DataTable()
                    .columns.adjust();
            });
        })
        $(document).ready(function() {


            $("#icons").click(function(e) {

                $('#exampleModal').modal('show');


            })
            $("#icons").click(function(e) {

                $('#exampleModal').modal('show');


            })
            $(".terms").click(function(e) {

                $('#termsModal').modal('show');
                $('#termsModal #terms').val(this.id)


            })


            $(".update").click(function(e) {

                $('#updateModal').modal('show');
                $('#updateModal #id').val($(this).data('id'))
                $('#updateModal #name').val($(this).data('name'))

                $('#updateModal select').val($(this).data('catogery'))
                console.log($('#updateModal select').val());

                // $('#updateModal #id').val(this.parent().find('#name'))
                // console.log($(this).parent().parent().find('td #name').val());

            })
            $(".icons_modal").click(function(e) {
                e.preventDefault

                $("#icon_name").val(this.id);

                // console.log( $("#icons_modal").find('.fa')[0].attr('id'));
            })
        });

        $(".delete").click(function(e) {

            $('#deleteModal').modal('show');
            $('#deleteModal #id').val($(this).data('id'))
            $('#deleteModal #name').val($(this).data('name'))



            // $('#updateModal #id').val(this.parent().find('#name'))
            // console.log($(this).parent().parent().find('td #name').val());

        })
    </script>
<?php $__env->stopSection(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\Qoutaion_system\resources\views/catogery/index.blade.php ENDPATH**/ ?>