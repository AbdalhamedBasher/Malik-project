
    <div class="container p-2">
        <div class="row" >
            <div class="col-lg-12">
                <div class="breadcrumb_iner">
                    <div class="breadcrumb_iner_item">

     <?php if(App\Models\line::find($master)): ?>
     <p><a href="" class="text-white text-bold"><?php echo e(App\Models\line::find($master)->name); ?></a><span>/</span><a href="<?php echo e(url('lines/'.App\Models\line::find($master)->main_line)); ?>" class="text-white" disabled><?php echo e($breadcrumb); ?></a></p>

     <?php else: ?>
     <p><a href="<?php echo e(url('lines/')); ?>" class="text-white text-bold">النشاطات</a></p>

     <?php endif; ?>
                     </div>
                </div>
            </div>
        </div>
    </div>

<?php /**PATH C:\Users\user\Documents\GitHub\Qoutaion_system\resources\views/partials/breadcrumb.blade.php ENDPATH**/ ?>