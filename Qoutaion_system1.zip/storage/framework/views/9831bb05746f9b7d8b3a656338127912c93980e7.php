<?php $__env->startSection('content'); ?>
    
    <div class="content">
        <div class="row">
            <div class="col-lg-12">
                <div class="card" style="background-color:#433483a3 ; min-hight:3rem ; hight:300px">
                    <?php echo $__env->make('partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card">

                    <div class="container py-1">
                        <div class="row row-cols-2 row-cols-sm-2 row-cols-md-4 justify-content-center">







                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                                <div class="col-lg-2 col-sm-6 grid-column py-3">
                                    <a href="<?php echo e(url('lines/'.$item->id)); ?>" class="">
                                        <div
                                            class="grid-item border p-4 rounded-xl text-center position-relative shadow-xl hover:shadow-lg">
                                            <i class="fa fas fa-users fa-2x pb-2" style="
                                     color:#433483a3;
                                                    "></i><br>
                                            <span class="font-weight-bold"><?php echo e($item->name); ?></span>
                                        </div>
                                    </a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <div class="col-lg-2 col-sm-6 grid-column py-3">
                                    <a href="<?php echo e(isset($master)?url('quote/'.$master):''); ?>" class="" <?php echo e(isset($master)?'#':''); ?>>
                                        <div
                                            class="grid-item border p-4 rounded-xl text-center position-relative shadow-xl hover:shadow-lg">
                                            <i class="fa fas fa fa-file-text-o fa-2x pb-2" style="
                                     color:#433483a3;
                                                    "></i><br>
                                            <span class="font-weight-bold">الفواتير</span>
                                        </div>
                                    </a>
                                </div>





                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script>
        function sendMarkRequest(id = null) {
            return $.ajax("#", {
                method: 'POST',

                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    id
                }
            });
        }
        $(function() {
            $('.mark-as-read').click(function() {
                let request = sendMarkRequest($(this).data('id'));
                request.done(() => {
                    $(this).parents('div.alert').remove();
                });
            });
            $('#mark-all').click(function() {
                let request = sendMarkRequest();
                request.done(() => {
                    $('div.alert').remove();
                })
            });
        });
    </script>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\Qoutaion_system\resources\views/lines/index.blade.php ENDPATH**/ ?>